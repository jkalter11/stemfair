# Smart-Assistant-Voice-Recognition-C-.Net
 I was created simple assistant on my computer, that was writed and build on C#.Net
 
## Tools
Visual Studio

## Net Framework 4.0

## Screenshoot
<img src="https://raw.githubusercontent.com/lamhotsimamora/Smart-Assistant-Voice-Recognition-C-.Net/master/gosmart-lamhot-simamora.JPG" width="500" height="500">

## Getting Started
1. Open Visual Studio
2. Clone this repository to your folder
```
 https://github.com/lamhotsimamora/Smart-Assistant-Voice-Recognition-C-.Net.git
```
3. Open project file
4. Set up the net framework to be 4.0
5. Rebuild project
5. Done

## Run Program
If you want to RUN the application, you can run the file executable in <strong>'./VoiceRecognition/bin/Debug/GoSmart.exe'</strong>


## Demo On Youtube
You can watch demo on youtube https://www.youtube.com/watch?v=iOjg72Dvwr0


## Compatible 
This application was tested in Windows 7. If you have windows XP, it might not work.


